/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author clare
 */
public class UserAccountDirectory {
    private static ArrayList<UserAccount> userAccDirList;

    public UserAccountDirectory(){
        userAccDirList = new ArrayList<UserAccount>();
    }
    
    public ArrayList<UserAccount> getUserAccDirList() {
        return userAccDirList;
    }

    public void setUserAccDirList(ArrayList<UserAccount> userAccDirList) {
        this.userAccDirList = userAccDirList;
    }
    
    public UserAccount addUserAccount(){
        UserAccount uAcc = new UserAccount();
        userAccDirList.add(uAcc);
        return uAcc;
    }
    
    public void deleteUserAccount(UserAccount acc){
        userAccDirList.remove(acc);
    }
    
    public UserAccount isValidUser(String userID, String password){
        for(UserAccount ua : userAccDirList){
           if(ua.getUserId().equals(userID) && ua.getPassword().equals(password)){
               return ua;
           }
        }
        return null;
    }
}
