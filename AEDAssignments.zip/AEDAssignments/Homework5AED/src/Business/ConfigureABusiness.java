/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author clare
 */
public class ConfigureABusiness {
    
    public static Business Initialize(String n){
        Business b = new Business(n);
        PersonDirectory pd = b.getPersonDirectory();
        UserAccountDirectory uad = b.getUserAccountDirectory();
        
        UserAccount uAdmin = uad.addUserAccount();
        UserAccount uhr = uad.addUserAccount();
        
        // Record to create Person Details liked to HR admin
        Person hr = pd.addPerson();
        hr.setUserAccount(uhr);
        hr.setFirstname("Anne");
        hr.setLastname("Wells");
        
        //Record to create Person Details liked to System Admin
        Person admin = pd.addPerson();
        admin.setUserAccount(uAdmin);
        admin.setFirstname("John");
        admin.setLastname("Adam");
        
       //Record to create User Account details linked to System Admin
            uAdmin.setPerson(admin);
            uAdmin.setUserId("jadam");
            uAdmin.setPassword("jadam123");
            uAdmin.setRole("System Admin");
        
       
        //Record to create User Account details linked to HR Admin
            //UserAccount uhr = uad.addUserAccount();
            uhr.setPerson(hr);
            uhr.setUserId("awells");
            uhr.setPassword("awells123");
            uhr.setRole("HR Admin");
        
        return b;
    }
}
