/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author clare
 */
public class Airplanes {
    private String airplaneName;
    private String manYear;
    private String manBy;
    private int maxCapacity;
    private long serialNum;
    private String modelNum;
    private int bookedSeats;
    private String isMaintainenceExpired;
    private boolean isAvailable;
    private String availableTime;
    private String airportAt;
    private String departTime;
    

    public String getAirplaneName() {
        return airplaneName;
    }

    public void setAirplaneName(String airplaneName) {
        this.airplaneName = airplaneName;
    }

    public String getManYear() {
        return manYear;
    }

    public void setManYear(String manYear) {
        this.manYear = manYear;
    }

    public String getManBy() {
        return manBy;
    }

    public void setManBy(String manBy) {
        this.manBy = manBy;
    }

    public int getMaxCapacity() {
        return maxCapacity;
    }

    public void setMaxCapacity(int maxCapacity) {
        this.maxCapacity = maxCapacity;
    }

    public long getSerialNum() {
        return serialNum;
    }

    public void setSerialNum(long serialNum) {
        this.serialNum = serialNum;
    }

    public String getModelNum() {
        return modelNum;
    }

    public void setModelNum(String modelNum) {
        this.modelNum = modelNum;
    }

    public int getBookedSeats() {
        return bookedSeats;
    }

    public void setBookedSeats(int bookedSeats) {
        this.bookedSeats = bookedSeats;
    }

    public String getIsMaintainenceExpired() {
        return isMaintainenceExpired;
    }

    public void setIsMaintainenceExpired(String isMaintainenceExpired) {
        this.isMaintainenceExpired = isMaintainenceExpired;
    }
    

    public boolean isIsAvailable() {
        return isAvailable;
    }

    public void setIsAvailable(boolean isAvailable) {
        this.isAvailable = isAvailable;
    }

    public String getAvailableTime() {
        return availableTime;
    }

    public void setAvailableTime(String availableTime) {
        this.availableTime = availableTime;
    }

    public String getAirportAt() {
        return airportAt;
    }

    public void setAirportAt(String airportAt) {
        this.airportAt = airportAt;
    }

    public String getDepartTime() {
        return departTime;
    }

    public void setDepartTime(String departTime) {
        this.departTime = departTime;
    }
    @Override
    public String toString()
    {
        return this.airplaneName;
    }
    
}
