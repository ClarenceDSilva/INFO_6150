/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author clare
 */
public class Fleet {

    private ArrayList<Airplanes> fleet;
    public ArrayList<Airplanes> getFleet() {
        return fleet;
    }

    public void setFleet(ArrayList<Airplanes> fleet) {
        this.fleet = fleet;
    }

  
    public Fleet(){
        fleet = new ArrayList<Airplanes>();
      }
    
    public Airplanes addAirplane(){
        Airplanes air = new Airplanes();
        fleet.add(air);
        return air;
    }
    
    public void removeAirplaneData(Airplanes air){
        fleet.remove(air);
    }
}
