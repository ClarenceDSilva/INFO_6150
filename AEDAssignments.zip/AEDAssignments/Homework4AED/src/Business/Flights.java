/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author clare
 */
public class Flights {
    private String airlineName;
    private String flightId;
    private String source;
    private String destination;
    private String date;
    private String departTime;
    private String arrivalTime;
    private int capacity;
    private int bookedSeats;
    
    private ArrayList<Customer> flight;

    public String getAirlineName() {
        return airlineName;
    }

    public void setAirlineName(String airlineName) {
        this.airlineName = airlineName;
    }

    public String getFlightId() {
        return flightId;
    }

    public void setFlightId(String flightId) {
        this.flightId = flightId;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getDepartTime() {
        return departTime;
    }

    public void setDepartTime(String departTime) {
        this.departTime = departTime;
    }

    public String getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(String arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getBookedSeats() {
        return bookedSeats;
    }

    public void setBookedSeats(int bookedSeats) {
        this.bookedSeats = bookedSeats;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public ArrayList<Customer> getFlight() {
        return flight;
    }

    public void setFlight(ArrayList<Customer> flight) {
        this.flight = flight;
    }
    
   public Flights(){
       flight = new ArrayList<Customer>();
   }
   
   public Customer addCustDetails(){
       Customer cust = new Customer();
       flight.add(cust);
       return cust;
   }
    @Override
    public String toString(){
        return this.source;
    } 
}
