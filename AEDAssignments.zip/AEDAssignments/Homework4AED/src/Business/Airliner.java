/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author clare
 */
public class Airliner {
    
    public String airlineNam;
    private ArrayList<Flights> airliner;

    public ArrayList<Flights> getAirliner() {
        return airliner;
    }

    public void setAirliner(ArrayList<Flights> airliner) {
        this.airliner = airliner;
    }
    
    public Airliner(){
        airliner = new ArrayList<Flights>();
    }

    public String getAirlineNam() {
        return airlineNam;
    }

    public void setAirlineNam(String airlineNam) {
        this.airlineNam = airlineNam;
    }
    
    
    
    public Flights addFlight(){
        Flights flights = new Flights();
        airliner.add(flights);
        return flights;
    }
    
    public void deleteFlight(Flights flight){
        airliner.remove(flight);
    }
    
    public Flights searchFlight(String flightId){
        for(Flights flight : airliner){
            if(flight.getFlightId().equalsIgnoreCase(flightId)){
                return flight;
            }
        }
        return null;
    }
   
     @Override
     public String toString(){
        return this.airlineNam;
    } 
}
