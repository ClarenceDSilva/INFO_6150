/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 *
 * @author clare
 */
public class TravelPortal {
    
     public static void main(String[] args) throws ParseException  { 
        TravelPortal tp = new TravelPortal();
        Airliner air = getAirplaneCsv();
        FlightSchedule fs = getFlightScheduleCsv();
        Flight f = getSeatCsv();
        
        System.out.println("FETCHING AIRPLANE CSV FILE:");
        tp.getAirplaneCsv();
        System.out.println("FETCHING SEAT CSV FILE:");
        tp.getSeatCsv();
        System.out.println("FETCHING FLIGHT SCHEDULE CSV FILE: \n");
        tp.getFlightScheduleCsv();
        
        int totalRevenue = 0;
        // Initializing prices for each seats
        int window = 200;
        int middle = 150;
        int asile = 100;
         
         Map<String, Integer> finalDetails = new HashMap<String, Integer>();
         
        try{
        for(int i = 0; i< air.getAirlinerList().size(); i++){
            int eachFlightRevenue = 0;
            int eachFlightRevenueWindow = 0;
            int eachFlightRevenueMiddle = 0;
            int eachFlightRevenueAsile = 0;
            
            
            for(int j=0; j< fs.getFlightSchFli().size(); j++ ){
                //System.out.println("Airline List "+air.getAirlinerList().get(i).getSerialNum());
                //System.out.println("Flight List "+fs.getFlightSchFli().get(j).getSerialNum());
                if(air.getAirlinerList().get(i).getSerialNum().equals(fs.getFlightSchFli().get(j).getSerialNum())){
                    //System.out.println("SERIAL NUMBER MATCHED");
                    //System.out.println(air.getAirlinerList().get(i).getSerialNum());
                    for(int k = 0; k< f.getFlight().size(); k++ ){
                        if((f.getFlight().get(k).getSeatType().equals("Window")) && (f.getFlight().get(k).getIsAvailable().equals("N"))){
                           eachFlightRevenueWindow += window;
                        }if(f.getFlight().get(k).getSeatType().equals("Middle") && (f.getFlight().get(k).getIsAvailable().equals("N"))){
                          eachFlightRevenueMiddle += middle;
                         
                        }if (f.getFlight().get(k).getSeatType().equals("Asile") && (f.getFlight().get(k).getIsAvailable().equals("N"))){
                          eachFlightRevenueAsile += asile;
                        }
            
                    }         
                  
                }    
                    
            }
                
                    // Calculating revenues of flights at a particular destination
              eachFlightRevenue = eachFlightRevenueWindow + eachFlightRevenueMiddle + eachFlightRevenueAsile;
              System.out.println("REVENUE EARNED BY FLIGHT "+air.getAirlinerList().get(i).getAirplaneName()+" FOR THE JOURNEY T0 "+air.getAirlinerList().get(i).getAirportAt()+ " is  $"+ eachFlightRevenue+"\n");
              

                     
            // Adding the Airline names to the finalAirplaneDetails array list so that uniqiue values exist
            String airplaneName = air.getAirlinerList().get(i).getAirplaneName();
            if(!(finalDetails.containsKey(airplaneName))){
                finalDetails.put(airplaneName, eachFlightRevenue);
                //int hMapSize = finalDetails.size();
               // System.out.println("HASH MAP SIZE"+ hMapSize);
            
            }else{
               Integer searchHashValue = finalDetails.get(airplaneName);
               
                Integer ef = searchHashValue + eachFlightRevenue;
                finalDetails.put(airplaneName, ef);
                //int hMapSize = finalDetails.size();
                //System.out.println("HASH MAP SIZE"+ hMapSize);

            }
            
        }
                System.out.println("REVENUE EARNED BY THE INDIVIDUAL FLIGHTS ARE:");
                Iterator it = finalDetails.entrySet().iterator();
                while(it.hasNext()){
                    Map.Entry pair = (Map.Entry)it.next();
                    System.out.println(pair.getKey() + " ======= $" + pair.getValue());
                }
                    
                for(String key : finalDetails.keySet()){
                    totalRevenue += finalDetails.get(key);
                }
                System.out.println("\nTOTAL REVENUE OF THE TRAVEL AGENCY IS: $"+ totalRevenue);
         } catch(Exception e){
            e.printStackTrace();
        } 
        
}
   
    ////////////////////////////////////////////////////////////////// CSV DETAILS///////////////////////////////////////////////////////////////////////////////////////////////////////
    public static Airliner getAirplaneCsv(){
        String csvFile = "Airplane.csv";
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";
        Airliner airliner = new Airliner();
         try {
            br = new BufferedReader(new FileReader(csvFile));
            while ((line = br.readLine()) != null) {
                
              String[] airlinerElement = line.split(cvsSplitBy);
              Airplane airplane = airliner.addAirplane();
              String airplaneName = airlinerElement[0];
              String manYear = airlinerElement[1];
              String airportAt = airlinerElement[2];
              String serialNum = airlinerElement[3];
              
              airplane.setAirplaneName(airplaneName);
              airplane.setManYear(manYear);
              airplane.setSerialNum(serialNum);
              airplane.setAirportAt(airportAt);
            }
                
            for(Airplane a : airliner.getAirlinerList()){
                //System.out.println("Airplane Name-->"+a.getAirplaneName()+"Man Year--->"+a.getManYear()+"Airport At--->"+a.getAirportAt()+"Serial Number"+a.getSerialNum());
            }

                // use comma as separator
           
            } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
         return airliner;
    }
    
    public static Flight getSeatCsv(){
        String csvFile = "Seat.csv";
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";
        Flight flight = new Flight();
        try {

            br = new BufferedReader(new FileReader(csvFile));
            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] seatElement = line.split(cvsSplitBy);
                Seat seat = flight.addSeat();
                String seatNumber = seatElement[0];
                String seatType = seatElement[1];
                String isAvailable = (seatElement[2]);
                seat.setSeatNumber(seatNumber);
                seat.setSeatType(seatType);
                seat.setIsAvailable(isAvailable); 
    }
            int i;
            for(Seat s : flight.getFlight()){
                //System.out.println("SeatNumber-->"+s.getSeatNumber()+"Seat Type-->"+s.getSeatType()+"Is Available-->"+s.getIsAvailable());
            }
        }catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
            return flight;
    }
    
    public static FlightSchedule getFlightScheduleCsv(){
        String csvFile = "FlightSchedule.csv";
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";
        
        FlightSchedule flSch = new FlightSchedule();
        try{
            br = new BufferedReader(new FileReader(csvFile));
            while ((line = br.readLine()) != null) {

                // use comma as separator
                String[] seatElement = line.split(cvsSplitBy);
                
                Flight flight = flSch.addFlight();
                String date = seatElement[0];
                String departTime = seatElement[1];
                String arrvTime = seatElement[2];
                String serialNum = seatElement[3];
                
                flight.setDate(date);
                flight.setDepartTime(departTime);
                flight.setArrivalTime(arrvTime);
                flight.setSerialNum(serialNum);
        }
         for(Flight flight : flSch.getFlightSchFli()){
             //System.out.println("Date--> "+ flight.getDate()+"Departure Time--> "+ flight.getDepartTime()+"Arrival Time--> "+flight.getArrivalTime()+"Serial Number--> "+flight.getSerialNum());
             
        }
        }catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }  
        return flSch;
    }
       
   }
