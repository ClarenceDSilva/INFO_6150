/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author clare
 */
public class FlightSchedule {
    //schedule of different flights
    public ArrayList<Flight> flightSchFli;
    public ArrayList<Airliner> flightSchAir;

    public ArrayList<Flight> getFlightSchFli() {
        return flightSchFli;
    }

    public void setFlightSchFli(ArrayList<Flight> flightSchFli) {
        this.flightSchFli = flightSchFli;
    }

    public ArrayList<Airliner> getFlightSchAir() {
        return flightSchAir;
    }

    public void setFlightSchAir(ArrayList<Airliner> flightSchAir) {
        this.flightSchAir = flightSchAir;
    }

    public FlightSchedule(){
        this.flightSchFli = new ArrayList<>();
    }
    
    public Flight addFlight(){
        Flight flight = new Flight();
        flightSchFli.add(flight);
        return flight;
    }
    
      
    
}
