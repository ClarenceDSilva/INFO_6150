/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author clare
 */
public class Flight {
    private String date;
    //private String time;
    private String departTime;
    private String arrivalTime;
    private String serialNum;
    
    private ArrayList<Seat> flight;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setFlight(ArrayList<Seat> flight) {
        this.flight = flight;
    }

    public String getDepartTime() {
        return departTime;
    }

    public void setDepartTime(String departTime) {
        this.departTime = departTime;
    }

    public String getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(String arrivalTime) {
        this.arrivalTime = arrivalTime;
    }
    
    public ArrayList<Seat> getFlight() {
        return flight;
    }

    public String getSerialNum() {
        return serialNum;
    }

    public void setSerialNum(String serialNum) {
        this.serialNum = serialNum;
    }
    
    public Flight(){
        this.flight = new ArrayList<>();
      }
    
    public Seat addSeat(){
        Seat s = new Seat();
        flight.add(s);
        return s;
    }
    
       
}
