/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author clare
 */
public class CustomerDirectory {
    // TA will have one CustDirectory and cust direct will contain details of person.
    
    TravelAgency agency;
    FlightSchedule schedule;

    public TravelAgency getAgency() {
        return agency;
    }

    public void setAgency(TravelAgency agency) {
        this.agency = agency;
    }

    public FlightSchedule getSchedule() {
        return schedule;
    }

    public void setSchedule(FlightSchedule schedule) {
        this.schedule = schedule;
    }
    
    public CustomerDirectory(){
        agency = new TravelAgency();
        schedule = new FlightSchedule();
    }
}
