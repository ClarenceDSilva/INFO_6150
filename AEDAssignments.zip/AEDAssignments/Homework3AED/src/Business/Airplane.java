/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author clare
 */
public class Airplane {
    private String airplaneName;
    private String manYear;
    //private String manBy;
    //private int maxCapacity;
    private String serialNum;
    private String modelNum;
    //private int bookedSeats;
    //private String isMaintainenceExpired;
    //private boolean isAvailable;
    //private String availableTime;
    private String airportAt;
    //private String departTime;
    
    
    //One airplane to many flights
    private ArrayList<Flight> airplane;

    public String getAirplaneName() {
        return airplaneName;
    }

    public void setAirplaneName(String airplaneName) {
        this.airplaneName = airplaneName;
    }

    public String getManYear() {
        return manYear;
    }

    public void setManYear(String manYear) {
        this.manYear = manYear;
    }

    public ArrayList<Flight> getAirplane() {
        return airplane;
    }

    public void setAirplane(ArrayList<Flight> airplane) {
        this.airplane = airplane;
    }

    public String getModelNum() {
        return modelNum;
    }

    public void setModelNum(String modelNum) {
        this.modelNum = modelNum;
    }

    public String getAirportAt() {
        return airportAt;
    }

    public void setAirportAt(String airportAt) {
        this.airportAt = airportAt;
    }

    public String getSerialNum() {
        return serialNum;
    }

    public void setSerialNum(String serialNum) {
        this.serialNum = serialNum;
    }
    
    
}
