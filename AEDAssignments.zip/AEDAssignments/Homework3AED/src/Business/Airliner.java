/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author clare
 */
public class Airliner {
    
    private ArrayList<Airplane> airlinerList;

    public ArrayList<Airplane> getAirlinerList() {
        return airlinerList;
    }

    public void setAirlinerList(ArrayList<Airplane> airlinerList) {
        this.airlinerList = airlinerList;
    }
    
    public Airliner(){
        this.airlinerList = new ArrayList<>();
    }
    
    public Airplane addAirplane(){
        Airplane airplane = new Airplane();
        airlinerList.add(airplane);
        return airplane;
    }
}
