/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Role.ManufacturerRole;
import Business.Role.Role;
import Business.Vaccine.Vaccine;
import java.util.ArrayList;

/**
 *
 * @author clare
 */
public class ManufacturerOrganization extends Organization {

    private VaccineInventory vi;

    public ManufacturerOrganization(){
        super(Organization.Type.Manufacturer.getValue());
        vi = new VaccineInventory();
    }
    
    public int getAvailVaccineCount(String vName)
    {
        return vi.getAvailVaccineCount(vName);
    }

    public VaccineInventory getVaccineInventory() {
        return vi;
    }

    public void setVaccineInventory(VaccineInventory vi) {
        this.vi = vi;
    }
       
    
    @Override
    public ArrayList<Role> getSupportedRole() {
        ArrayList<Role> roles = new ArrayList();
        roles.add(new ManufacturerRole());
        return roles;
    }
    
}
