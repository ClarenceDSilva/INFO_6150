/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Vaccine.Vaccine;
import java.util.ArrayList;


public class VaccineInventory {
    private ArrayList<Vaccine> vaccineList;
    
    public VaccineInventory()
    {
        vaccineList = new ArrayList();
    }

    public ArrayList<Vaccine> getVaccineList() {
        return vaccineList;
    }

    public void setVaccineList(ArrayList<Vaccine> vaccineList) {
        this.vaccineList = vaccineList;
    }
    
    public Vaccine createVaccine()
    {
        Vaccine vi = new Vaccine();
        vaccineList.add(vi);
        return vi;
    }
    
    public void removeVaccine(String vaccineName, int count)
   {
       for(Vaccine v :vaccineList)
       {
           if(v.getVaccineName().equals(vaccineName))
           {
               int oldCount = v.getCount();
               v.setCount(oldCount - count);
           }
       }
   }
    
     public void addVaccineToInventory(String vaccineName, int count)
   {
       int oldCount = -1;
       for(Vaccine v :vaccineList)
       {
           if(v.getVaccineName().equals(vaccineName))
           {
               oldCount = v.getCount();
               v.setCount(oldCount + count);
           }
       }
       if(oldCount == -1)
       {
           Vaccine v = this.createVaccine();
           v.setVaccineName(vaccineName);
           v.setCount(count);
       }
   }
    
    public int getAvailVaccineCount(String vName)
    {
        int count= -1;
        
        for(Vaccine vi : vaccineList)
        {
            if(vName.equals(vi.getVaccineName()))
            {
                count = vi.getCount();
            }
        }
        return count;
    }
    
}
