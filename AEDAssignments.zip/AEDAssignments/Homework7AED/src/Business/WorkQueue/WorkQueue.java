/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import java.util.ArrayList;

/**
 *
 * @author clare
 */
public class WorkQueue {
    private ArrayList<WorkRequest> requestList;
    
    public WorkQueue()
    {
        requestList = new ArrayList();
    }

    public ArrayList<WorkRequest> getRequestList() {
        return requestList;
    }

    public WorkRequest addRequest() {
        WorkRequest w = new WorkRequest() {};
        requestList.add(w);
        return w;
    }
    
    
    
    
}
