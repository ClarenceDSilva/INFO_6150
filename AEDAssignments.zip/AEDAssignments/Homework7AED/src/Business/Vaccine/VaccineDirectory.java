/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Vaccine;

import java.util.ArrayList;

/**
 *
 * @author clare
 */
public class VaccineDirectory {
    private ArrayList<Vaccine> vaccineList;
    
    public VaccineDirectory(){
        vaccineList = new ArrayList<Vaccine>();
    }

    public ArrayList<Vaccine> getVaccineList() {
        return vaccineList;
    }

    public Vaccine createAndAddVaccine(){
        Vaccine v = new Vaccine();
       // if(v.isIsApproved()){  //Checking if the vaccine is approved by the CDC
            vaccineList.add(v);
        //}
        return v;
    }
}
