/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;

import java.util.ArrayList;

/**
 *
 * @author clare
 */
public class EnterpriseDirectory {
    
    private ArrayList<Enterprise> enterprises;
    
    public EnterpriseDirectory()
    {
        enterprises = new ArrayList();
    }

    public ArrayList<Enterprise> getEnterpriseList() {
        return enterprises;
    }

    public void setEnterprises(ArrayList<Enterprise> enterprises) {
        this.enterprises = enterprises;
    }
    
      public Enterprise createAndAddEnterprise(String name, Enterprise.EnterpriseType type){
        Enterprise enterprise = null;
        if (type == Enterprise.EnterpriseType.CDC){
            enterprise = new CDCEnterprise(name);
            enterprises.add(enterprise);
        }
        else if(type == Enterprise.EnterpriseType.Distributor){
            enterprise = new DistributorEnterprise(name);
            enterprises.add(enterprise);
        }
        else if(type == Enterprise.EnterpriseType.StateDept){
            enterprise = new StateDeptEnterprise(name);
            enterprises.add(enterprise);
        }
        return enterprise;
    }
}
