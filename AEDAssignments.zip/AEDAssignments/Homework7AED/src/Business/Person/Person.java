/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Person;

import Business.Employee.Employee;
import Business.Enterprise.Enterprise;
import Business.Role.Role;
import Business.UserAccount.UserAccount;
import java.util.ArrayList;

/**
 *
 * @author clare
 */
public class Person{
    private String name;
    private UserAccount ua;
    private Enterprise enterprize;
    private Employee employee;
    
    public Person(String name, Enterprise enterprize) {
        this.name = name;
        this.enterprize = enterprize;
        
//        ua = new UserAccount();
//        ua.setUsername(uname);
//        ua.setPassword(pwd);
//        setUa(ua);
        //organization.getUserAccountDirectory().authenticateUser(uname, pwd);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Enterprise getEnterprize() {
        return enterprize;
    }

    public void setEnterprize(Enterprise enterprize) {
        this.enterprize = enterprize;
    }

    public UserAccount getUa() {
        return ua;
    }

    public void setUa(UserAccount ua) {
        this.ua = ua;
    }

    @Override
    public String toString()
    {
        return getName();
    }
    
}
