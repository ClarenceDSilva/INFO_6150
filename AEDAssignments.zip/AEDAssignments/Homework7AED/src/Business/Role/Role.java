/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Role;

import Business.EcoSystem;
import Business.Enterprise.Enterprise;
import Business.Organization.Organization;
import Business.UserAccount.UserAccount;
import javax.swing.JPanel;

/**
 *
 * @author clare
 */
public abstract class Role {
    
     public enum roleType{
        Admin("Admin Role"){
            
        },
        Doctor("Doctor Role"){
            
        },
        Lab("Lab Role"){
            
        };
        private String value;
        private roleType(String value)
        {
            this.value = value;
        }
        public String getValue()
        {
            return value;
        }
        
        
    }
     
     public abstract JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, Organization org, Enterprise enterprise, EcoSystem ecoSystem);
}
