/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author clare
 */
public class CreditCard {
    private long cardNumber;
    private String nameOnTheCard;
    private String validityMonth;
    private String validityYear;
    private int securityPin;

    public long getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(long cardNumber) {
        this.cardNumber = cardNumber;
    }

    public int getSecurityPin() {
        return securityPin;
    }

    public void setSecurityPin(int securityPin) {
        this.securityPin = securityPin;
    }

   

    public String getNameOnTheCard() {
        return nameOnTheCard;
    }

    public void setNameOnTheCard(String nameOnTheCard) {
        this.nameOnTheCard = nameOnTheCard;
    }

    public String getValidityMonth() {
        return validityMonth;
    }

    public void setValidityMonth(String validityMonth) {
        this.validityMonth = validityMonth;
    }

    public String getValidityYear() {
        return validityYear;
    }

    public void setValidityYear(String validityYear) {
        this.validityYear = validityYear;
    }
    
/*    public CreditCard(String cardNumber, String nameOnTheCard, String validityMonth, String validityYear, String securityPin){
        this.cardNumber = cardNumber;
        this.nameOnTheCard = nameOnTheCard;
        this.validityMonth = validityMonth;
        this.validityYear = validityYear;
    }*/

   
}
