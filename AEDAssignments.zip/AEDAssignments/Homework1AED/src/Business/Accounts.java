/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author clare
 */
public class Accounts {
    private long checkingAccNumber;
    private String checkingAccName;
    private String checkingCreationDate;
    
    private long savingsAccNumber;
    private String savingsAccName;
    private String savingsCreationDate;
    
    private boolean active;
    private boolean inactive;

    public long getCheckingAccNumber() {
        return checkingAccNumber;
    }

    public void setCheckingAccNumber(long checkingAccNumber) {
        this.checkingAccNumber = checkingAccNumber;
    }

    public long getSavingsAccNumber() {
        return savingsAccNumber;
    }

    public void setSavingsAccNumber(long savingsAccNumber) {
        this.savingsAccNumber = savingsAccNumber;
    }

    

    public String getCheckingAccName() {
        return checkingAccName;
    }

    public void setCheckingAccName(String checkingAccName) {
        this.checkingAccName = checkingAccName;
    }

    public String getCheckingCreationDate() {
        return checkingCreationDate;
    }

    public void setCheckingCreationDate(String checkingCreationDate) {
        this.checkingCreationDate = checkingCreationDate;
    }

    public String getSavingsAccName() {
        return savingsAccName;
    }

    public void setSavingsAccName(String savingsAccName) {
        this.savingsAccName = savingsAccName;
    }

    public String getSavingsCreationDate() {
        return savingsCreationDate;
    }

    public void setSavingsCreationDate(String savingsCreationDate) {
        this.savingsCreationDate = savingsCreationDate;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isInactive() {
        return inactive;
    }

    public void setInactive(boolean inactive) {
        this.inactive = inactive;
    }

    
}
