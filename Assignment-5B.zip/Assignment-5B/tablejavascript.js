$(function() {
    $('button').attr('disabled',true);
});